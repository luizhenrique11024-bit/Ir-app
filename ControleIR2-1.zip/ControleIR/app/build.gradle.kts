plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.controleir"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.controleir.tv"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    // Chave fixa dentro do projeto: toda compilação (inclusive no GitHub) assina igual,
    // então as próximas atualizações instalam por cima sem desinstalar.
    signingConfigs {
        create("fixed") {
            storeFile = file("ir.p12")
            storeType = "pkcs12"
            storePassword = "controleir"
            keyAlias = "ir"
            keyPassword = "controleir"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sem dependências de propósito: nada de AndroidX, nada de SDK de anúncios/analytics.
