package br.controleir

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast

private val C_BG = 0xFF0E1114.toInt()
private val C_KEY = 0xFF1E252B.toInt()
private val C_KEY_P = 0xFF3F4D58.toInt()
private val C_RED = 0xFFC62828.toInt()
private val C_RED_P = 0xFFFF5F52.toInt()
private val C_SEL = 0xFF2E7D5B.toInt()
private val C_EDIT = 0xFFB26A00.toInt()

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private var ir: ConsumerIrManager? = null

    // Thread dedicada ao IR: o toque nunca espera o transmit() terminar.
    private val irThread = HandlerThread("ir", Process.THREAD_PRIORITY_URGENT_DISPLAY)
    private lateinit var irHandler: Handler

    @Volatile private var current: Profile = Presets.all[0]
    @Volatile private var heldKey: Key? = null
    @Volatile private var heldToggle = false
    private var toggle = false

    private var selected = 0           // 0..3 = presets, 4 = personalizado
    private var editMode = false
    private var customProto = Proto.SAMSUNG
    private var customAddr = 0x07
    private val customCodes = HashMap<Key, Int>()

    private val keyViews = HashMap<Key, TextView>()
    private val chips = ArrayList<TextView>()
    private lateinit var editChip: TextView
    private lateinit var banner: TextView
    private var density = 1f

    // ---- digitação pelo teclado do celular
    private val planner = Planner()
    private val typeQueue = java.util.concurrent.ConcurrentLinkedQueue<Step>()
    private val typing = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var lastSendAt = 0L
    @Volatile private var typeToggle = false
    private var kbOpen = false
    private var kbMode = 0                 // 0 = multi-toque (T9), 1 = grade ABC, 2 = grade QWERTY, 3 = grade personalizada
    private var kbCustom = Typing.QWERTY
    private var prevText = ""
    private var suppress = false
    private lateinit var kbBar: LinearLayout
    private lateinit var kbInput: EditText
    private lateinit var kbModeChip: TextView

    private val drain = object : Runnable {
        override fun run() {
            val s = typeQueue.poll()
            if (s == null) {
                finishTyping()
                return
            }
            typeToggle = !typeToggle
            send(current, s.key, typeToggle)
            lastSendAt = SystemClock.uptimeMillis()
            val next = typeQueue.peek()
            if (next == null) finishTyping() else irHandler.postDelayed(this, next.delayBefore)
        }
    }

    private fun finishTyping() {
        typing.set(false)
        if (!typeQueue.isEmpty() && typing.compareAndSet(false, true)) irHandler.post(drain)
    }

    private fun enqueue(steps: List<Step>) {
        if (steps.isEmpty()) return
        typeQueue.addAll(steps)
        if (typing.compareAndSet(false, true)) {
            val d = steps[0].delayBefore
            irHandler.postDelayed(drain, if (d > Typing.GAP) d else 0L)
        }
    }

    private val repeater = object : Runnable {
        override fun run() {
            val k = heldKey ?: return
            val t0 = SystemClock.uptimeMillis()
            send(current, k, heldToggle)
            if (heldKey != null) irHandler.postAtTime(this, t0 + current.proto.periodMs)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        prefs = getSharedPreferences("ir", MODE_PRIVATE)
        irThread.start()
        irHandler = Handler(irThread.looper)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        loadCustom()
        selected = prefs.getInt("sel", 0).coerceIn(0, 4)
        kbMode = prefs.getInt("kb_mode", 0).coerceIn(0, 3)
        kbCustom = prefs.getString("kb_custom", null) ?: Typing.QWERTY
        setContentView(buildUi())
        refreshProfile()
        if (ir?.hasIrEmitter() != true) {
            Toast.makeText(this, "Este aparelho não reporta emissor infravermelho.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        release()
        super.onPause()
    }

    override fun onDestroy() {
        irThread.quitSafely()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- envio IR

    private fun press(k: Key) {
        if (!current.codes.containsKey(k)) return
        toggle = !toggle
        val tg = toggle
        irHandler.removeCallbacks(repeater)
        irHandler.post { send(current, k, tg) }
        if (k.repeat) {
            heldKey = k
            heldToggle = tg
            irHandler.postDelayed(repeater, 350)   // só repete se segurar
        } else {
            heldKey = null
        }
    }

    private fun release() {
        heldKey = null
        irHandler.removeCallbacks(repeater)
    }

    private fun send(p: Profile, k: Key, tg: Boolean) {
        val cmd = p.codes[k] ?: return
        val pattern = when (p.proto) {
            Proto.NEC -> Ir.nec(p.addr, cmd)
            Proto.SAMSUNG -> Ir.samsung(p.addr, cmd)
            Proto.SONY -> Ir.sony(p.addr, cmd)
            Proto.RC5 -> Ir.rc5(p.addr, cmd, tg)
        }
        try {
            ir?.transmit(p.proto.carrier, pattern)
        } catch (e: Exception) {
            // sem emissor ou sem permissão: ignora
        }
    }

    // ---------------------------------------------------------------- perfis

    private fun loadCustom() {
        if (prefs.getBoolean("c_init", false)) {
            val name = prefs.getString("c_proto", "")
            customProto = Proto.entries.firstOrNull { it.name == name } ?: Proto.SAMSUNG
            customAddr = prefs.getInt("c_addr", 0x07)
            for (k in Key.entries) {
                if (prefs.contains("c_" + k.name)) customCodes[k] = prefs.getInt("c_" + k.name, 0)
            }
        } else {
            val base = Presets.samsung            // ponto de partida do perfil personalizado
            customProto = base.proto
            customAddr = base.addr
            customCodes.putAll(base.codes)
        }
    }

    private fun saveCustom() {
        val e = prefs.edit()
        e.putBoolean("c_init", true)
        e.putString("c_proto", customProto.name)
        e.putInt("c_addr", customAddr)
        for (k in Key.entries) {
            val c = customCodes[k]
            if (c != null) e.putInt("c_" + k.name, c) else e.remove("c_" + k.name)
        }
        e.apply()
    }

    private fun refreshProfile() {
        current = if (selected == 4) Profile("Pers.", customProto, customAddr, HashMap(customCodes))
        else Presets.all[selected]
        for ((k, v) in keyViews) {
            v.alpha = if (editMode || current.codes.containsKey(k)) 1f else 0.28f
        }
        chips.forEachIndexed { i, c -> c.background = shape(if (i == selected) C_SEL else C_KEY, 10) }
        editChip.background = shape(if (editMode) C_EDIT else C_KEY, 10)
        banner.visibility = if (editMode) View.VISIBLE else View.GONE
        banner.text = "Edição: toque num botão para definir o código (hex) e testar.\n" +
            "${customProto.label} · endereço 0x${hex(customAddr)} — toque aqui para alterar"
    }

    private fun select(i: Int) {
        selected = i
        if (i != 4) editMode = false
        prefs.edit().putInt("sel", i).apply()
        refreshProfile()
    }

    private fun toggleEdit() {
        editMode = !editMode
        if (editMode && selected != 4) {
            selected = 4
            prefs.edit().putInt("sel", 4).apply()
        }
        release()
        refreshProfile()
    }

    // ---------------------------------------------------------------- diálogos de edição

    private fun protoDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val group = RadioGroup(this)
        Proto.entries.forEachIndexed { i, p ->
            val rb = RadioButton(this)
            rb.text = p.label
            rb.id = 1000 + i
            rb.isChecked = (p == customProto)
            group.addView(rb)
        }
        val addr = EditText(this)
        addr.hint = "Endereço (hex)"
        addr.setText(hex(customAddr))
        addr.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        box.addView(group)
        box.addView(addr)
        val b = AlertDialog.Builder(this)
            .setTitle("Protocolo e endereço")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val idx = group.checkedRadioButtonId - 1000
                if (idx in Proto.entries.indices) customProto = Proto.entries[idx]
                parseHex(addr.text.toString())?.let { customAddr = it }
                saveCustom()
                refreshProfile()
            }
            .setNegativeButton("Cancelar", null)
        showNoAnim(b)
    }

    private fun codeDialog(k: Key) {
        val et = EditText(this)
        et.hint = "Comando (hex)"
        et.setText(customCodes[k]?.let { hex(it) } ?: "")
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        et.setSelectAllOnFocus(true)
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        val b = AlertDialog.Builder(this)
            .setTitle("Botão ${k.label}")
            .setView(box)
            .setPositiveButton("Salvar e testar") { _, _ ->
                val c = parseHex(et.text.toString())
                if (c != null) {
                    customCodes[k] = c and 0xFF
                    saveCustom()
                    refreshProfile()
                    toggle = !toggle
                    val tg = toggle
                    irHandler.post { send(current, k, tg) }
                }
            }
            .setNeutralButton("Remover") { _, _ ->
                customCodes.remove(k)
                saveCustom()
                refreshProfile()
            }
            .setNegativeButton("Cancelar", null)
        showNoAnim(b)
    }

    private fun showNoAnim(b: AlertDialog.Builder) {
        val d = b.create()
        d.window?.setWindowAnimations(0)
        d.show()
    }

    // ---------------------------------------------------------------- teclado do celular -> TV

    private fun gridRows(): List<String> =
        Typing.parse(
            when (kbMode) {
                1 -> Typing.ABC6
                2 -> Typing.QWERTY
                else -> kbCustom
            }
        )

    private fun setKb(open: Boolean) {
        kbOpen = open
        kbBar.visibility = if (open) View.VISIBLE else View.GONE
        suppress = true
        kbInput.setText("")
        suppress = false
        prevText = ""
        planner.reset()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (open) {
            kbInput.requestFocus()
            kbInput.post { imm.showSoftInput(kbInput, 0) }
        } else {
            typeQueue.clear()
            kbInput.clearFocus()
            imm.hideSoftInputFromWindow(kbInput.windowToken, 0)
        }
    }

    /** Compara o texto novo com o anterior: letras novas viram toques; letras apagadas viram "apagar". */
    private fun onKbText(now: String) {
        val old = prevText
        var p = 0
        val m = minOf(old.length, now.length)
        while (p < m && old[p] == now[p]) p++
        prevText = now

        val rows = gridRows()
        val settled = !typing.get() && SystemClock.uptimeMillis() - lastSendAt > Typing.SAME_KEY_WAIT + 100
        val steps = ArrayList<Step>()
        for (i in 0 until old.length - p) {
            if (kbMode == 0) {
                steps.add(Step(Key.DEL, Typing.GAP))
                planner.forgetLast()
            } else {
                steps.addAll(planner.backspaceGrid(rows))
            }
        }
        for (i in p until now.length) {
            if (kbMode == 0) steps.addAll(planner.t9(now[i], settled && steps.isEmpty()))
            else steps.addAll(planner.grid(rows, now[i]))
        }
        enqueue(steps)
    }

    private fun modeLabel(): String = when (kbMode) {
        0 -> "T9"
        1 -> "ABC"
        2 -> "QWE"
        else -> "Pers."
    }

    private fun kbModeDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val group = RadioGroup(this)
        val names = listOf(
            "Multi-toque (T9): usa as teclas numéricas",
            "Grade ABC (6 colunas, tipo Roku)",
            "Grade QWERTY",
            "Grade personalizada (campo abaixo)"
        )
        names.forEachIndexed { i, n ->
            val rb = RadioButton(this)
            rb.text = n
            rb.id = 2000 + i
            rb.isChecked = (i == kbMode)
            group.addView(rb)
        }
        val et = EditText(this)
        et.hint = "Uma linha por linha do teclado da TV.\n_ = espaço   < = apagar   > = enter"
        et.setText(kbCustom)
        et.textSize = 14f
        et.typeface = Typeface.MONOSPACE
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        box.addView(group)
        box.addView(et)
        val b = AlertDialog.Builder(this)
            .setTitle("Modo de digitação")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val idx = group.checkedRadioButtonId - 2000
                if (idx in 0..3) kbMode = idx
                val txt = et.text.toString()
                kbCustom = if (Typing.parse(txt).isEmpty()) Typing.QWERTY else txt
                prefs.edit().putInt("kb_mode", kbMode).putString("kb_custom", kbCustom).apply()
                kbModeChip.text = modeLabel()
                planner.reset()
            }
            .setNegativeButton("Cancelar", null)
        showNoAnim(b)
    }

    private fun buildKbBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.visibility = View.GONE

        kbInput = EditText(this)
        kbInput.hint = "Digite aqui → vai para a TV"
        kbInput.setHintTextColor(0xFF7B8794.toInt())
        kbInput.setTextColor(Color.WHITE)
        kbInput.textSize = 16f
        kbInput.isSingleLine = true
        kbInput.background = shape(C_KEY, 10)
        kbInput.setPadding(dp(12), 0, dp(12), 0)
        // Sem sugestões/autocorreção: cada letra chega ao app na hora, sem "texto em composição".
        kbInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        kbInput.imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        kbInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!suppress) onKbText(s?.toString() ?: "")
            }
        })
        kbInput.setOnEditorActionListener { _, _, _ ->
            // Tecla Enter do teclado do celular
            if (kbMode == 0) {
                planner.forgetLast()
                enqueue(listOf(Step(Key.OK, Typing.GAP)))
            } else {
                enqueue(planner.enterGrid(gridRows()))
            }
            true
        }
        bar.addView(kbInput, LinearLayout.LayoutParams(0, MATCH, 1f).also { it.setMargins(dp(3), dp(3), dp(3), dp(3)) })

        kbModeChip = chip(modeLabel()) { kbModeDialog() }
        kbModeChip.background = shape(C_EDIT, 10)
        bar.addView(kbModeChip, LinearLayout.LayoutParams(dp(54), MATCH).also { it.setMargins(dp(3), dp(3), dp(3), dp(3)) })

        // Reposiciona o cursor presumido no começo do teclado da TV (modo grade) e zera o T9.
        val sync = chip("⟲") { planner.reset() }
        sync.textSize = 20f
        bar.addView(sync, LinearLayout.LayoutParams(dp(44), MATCH).also { it.setMargins(dp(3), dp(3), dp(3), dp(3)) })

        // Apagar um caractere na TV (também é editável no modo Editar)
        bar.addView(key(Key.DEL, size = 20f), LinearLayout.LayoutParams(dp(48), MATCH).also { it.setMargins(dp(3), dp(3), dp(3), dp(3)) })

        val close = chip("✕") { setKb(false) }
        close.textSize = 18f
        bar.addView(close, LinearLayout.LayoutParams(dp(44), MATCH).also { it.setMargins(dp(3), dp(3), dp(3), dp(3)) })
        return bar
    }

    /** Botão que abre/fecha o teclado. Dispara no toque, como os demais. */
    private fun kbButton(): TextView {
        val t = TextView(this)
        t.text = "⌨︎"
        t.textSize = 22f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.isSoundEffectsEnabled = false
        val bg = StateListDrawable()
        bg.addState(intArrayOf(android.R.attr.state_pressed), shape(C_KEY_P, 14))
        bg.addState(intArrayOf(), shape(C_KEY, 14))
        t.background = bg
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    if (!editMode) setKb(!kbOpen)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.isPressed = false
            }
            true
        }
        return t
    }

    // ---------------------------------------------------------------- interface

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C_BG)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(b.left + dp(6), b.top + dp(6), b.right + dp(6), b.bottom + dp(6))
            WindowInsets.CONSUMED
        }

        // perfis
        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        val names = listOf("Samsung", "LG", "Sony", "RC5", "Pers.")
        names.forEachIndexed { i, n ->
            val c = chip(n) { select(i) }
            chips.add(c)
            chipRow.addView(c, chipParams())
        }
        editChip = chip("Editar") { toggleEdit() }
        chipRow.addView(editChip, chipParams())
        root.addView(chipRow, LinearLayout.LayoutParams(MATCH, WRAP))

        banner = TextView(this)
        banner.textSize = 12f
        banner.setTextColor(0xFFFFC107.toInt())
        banner.setPadding(dp(8), dp(4), dp(8), dp(4))
        banner.visibility = View.GONE
        banner.setOnClickListener { protoDialog() }
        root.addView(banner, LinearLayout.LayoutParams(MATCH, WRAP))

        // barra de digitação (escondida até tocar no botão de teclado)
        kbBar = buildKbBar()
        root.addView(kbBar, LinearLayout.LayoutParams(MATCH, dp(52)))

        // linha de cima
        root.addView(
            hrow(1.1f, key(Key.POWER, C_RED, C_RED_P), key(Key.SOURCE), key(Key.MUTE), kbButton())
        )

        // volume | direcional | canal
        val middle = LinearLayout(this)
        middle.orientation = LinearLayout.HORIZONTAL
        middle.layoutParams = LinearLayout.LayoutParams(MATCH, 0, 3.4f)

        val left = vcol(1.2f, key(Key.VOL_UP), key(Key.VOL_DOWN))
        val right = vcol(1.2f, key(Key.CH_UP), key(Key.CH_DOWN))
        val center = LinearLayout(this)
        center.orientation = LinearLayout.VERTICAL
        center.layoutParams = LinearLayout.LayoutParams(0, MATCH, 3f)
        center.addView(hrow(1f, View(this), key(Key.UP), View(this)))
        center.addView(hrow(1f, key(Key.LEFT), key(Key.OK), key(Key.RIGHT)))
        center.addView(hrow(1f, View(this), key(Key.DOWN), View(this)))
        middle.addView(left)
        middle.addView(center)
        middle.addView(right)
        root.addView(middle)

        // navegação
        root.addView(hrow(1f, key(Key.BACK), key(Key.HOME), key(Key.MENU), key(Key.EXIT)))

        // teclado numérico
        root.addView(hrow(1f, key(Key.D1, size = 20f), key(Key.D2, size = 20f), key(Key.D3, size = 20f)))
        root.addView(hrow(1f, key(Key.D4, size = 20f), key(Key.D5, size = 20f), key(Key.D6, size = 20f)))
        root.addView(hrow(1f, key(Key.D7, size = 20f), key(Key.D8, size = 20f), key(Key.D9, size = 20f)))
        root.addView(hrow(1f, View(this), key(Key.D0, size = 20f), View(this)))
        return root
    }

    private fun key(k: Key, color: Int = C_KEY, pressed: Int = C_KEY_P, size: Float = 17f): TextView {
        val t = TextView(this)
        t.text = k.label
        t.textSize = size
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.isSoundEffectsEnabled = false
        val bg = StateListDrawable()
        bg.addState(intArrayOf(android.R.attr.state_pressed), shape(pressed, 14))
        bg.addState(intArrayOf(), shape(color, 14))
        t.background = bg
        // Dispara no ACTION_DOWN (no instante do toque), sem esperar o "click" no soltar.
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    if (!editMode) {
                        press(k)
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    release()
                    if (editMode) codeDialog(k)
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    release()
                }
            }
            true
        }
        keyViews[k] = t
        return t
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.isSoundEffectsEnabled = false
        t.setOnClickListener { onClick() }
        return t
    }

    private fun chipParams(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        return lp
    }

    private fun hrow(weight: Float, vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(0, MATCH, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(v, lp)
        }
        r.layoutParams = LinearLayout.LayoutParams(MATCH, 0, weight)
        return r
    }

    private fun vcol(weight: Float, vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(MATCH, 0, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(v, lp)
        }
        r.layoutParams = LinearLayout.LayoutParams(0, MATCH, weight)
        return r
    }

    private fun shape(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    private fun hex(v: Int): String = Integer.toHexString(v).uppercase()

    private fun parseHex(s: String): Int? =
        s.trim().removePrefix("0x").removePrefix("0X").toIntOrNull(16)
}
