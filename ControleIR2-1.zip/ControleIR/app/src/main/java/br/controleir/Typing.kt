package br.controleir

/** Um toque de tecla IR na fila de digitação; delayBefore = espera (ms) antes de enviá-lo. */
class Step(val key: Key, val delayBefore: Long)

object Typing {
    /** Intervalo entre dois toques IR seguidos. */
    const val GAP = 170L

    /** Espera entre duas letras na mesma tecla numérica (multi-toque), para a TV confirmar a letra. */
    const val SAME_KEY_WAIT = 1200L

    const val QWERTY = "qwertyuiop\nasdfghjkl\nzxcvbnm"
    const val ABC6 = "abcdef\nghijkl\nmnopqr\nstuvwx\nyz1234\n567890"

    /** Uma linha por linha do teclado da TV. _ = espaço, < = apagar, > = enter. */
    fun parse(text: String): List<String> =
        text.lowercase().lines().map { it.trim() }.filter { it.isNotEmpty() }

    val LETTERS: Map<Key, String> = mapOf(
        Key.D2 to "abc", Key.D3 to "def", Key.D4 to "ghi", Key.D5 to "jkl",
        Key.D6 to "mno", Key.D7 to "pqrs", Key.D8 to "tuv", Key.D9 to "wxyz"
    )

    val DIGITS: List<Key> = listOf(
        Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6, Key.D7, Key.D8, Key.D9
    )
}

/** Converte caracteres digitados em sequências de teclas do controle. Guarda o estado entre caracteres. */
class Planner {
    private var last: Key? = null     // última tecla usada no modo multi-toque
    private var row = 0               // cursor presumido no teclado da TV (modo grade)
    private var col = 0

    fun reset() {
        last = null
        row = 0
        col = 0
    }

    fun forgetLast() {
        last = null
    }

    /** Multi-toque: a, b, c = tecla 2 pressionada 1, 2 ou 3 vezes. Espaço = tecla 0. */
    fun t9(ch: Char, settled: Boolean): List<Step> {
        val c = ch.lowercaseChar()
        val key: Key
        val n: Int
        if (c == ' ') {
            key = Key.D0
            n = 1
        } else if (c in 'a'..'z') {
            val e = Typing.LETTERS.entries.first { c in it.value }
            key = e.key
            n = e.value.indexOf(c) + 1
        } else if (c in '0'..'9') {
            if (c == '1') return emptyList()
            key = Typing.DIGITS[c - '0']
            n = if (c == '0') 2 else (Typing.LETTERS[key]?.length ?: 0) + 1
        } else {
            return emptyList()
        }
        val out = ArrayList<Step>()
        for (i in 0 until n) {
            val wait = if (i == 0 && last == key && !settled) Typing.SAME_KEY_WAIT else Typing.GAP
            out.add(Step(key, wait))
        }
        last = key
        return out
    }

    /** Grade: leva o cursor da TV até a letra com as setas e confirma com OK. */
    fun grid(rows: List<String>, ch: Char): List<Step> =
        gridTo(rows, if (ch == ' ') '_' else ch.lowercaseChar())

    fun backspaceGrid(rows: List<String>): List<Step> =
        if (rows.any { it.contains('<') }) gridTo(rows, '<') else listOf(Step(Key.DEL, Typing.GAP))

    fun enterGrid(rows: List<String>): List<Step> =
        if (rows.any { it.contains('>') }) gridTo(rows, '>') else emptyList()

    private fun gridTo(rows: List<String>, t: Char): List<Step> {
        if (rows.isEmpty()) return emptyList()
        var tr = -1
        var tc = -1
        for (r in rows.indices) {
            val c = rows[r].indexOf(t)
            if (c >= 0) {
                tr = r
                tc = c
                break
            }
        }
        if (tr < 0) return emptyList()

        var r = row.coerceIn(0, rows.size - 1)
        var c = col.coerceIn(0, rows[r].length - 1)
        val out = ArrayList<Step>()
        while (r < tr) {
            out.add(Step(Key.DOWN, Typing.GAP))
            r++
            c = minOf(c, rows[r].length - 1)
        }
        while (r > tr) {
            out.add(Step(Key.UP, Typing.GAP))
            r--
            c = minOf(c, rows[r].length - 1)
        }
        while (c < tc) {
            out.add(Step(Key.RIGHT, Typing.GAP))
            c++
        }
        while (c > tc) {
            out.add(Step(Key.LEFT, Typing.GAP))
            c--
        }
        out.add(Step(Key.OK, Typing.GAP))
        row = tr
        col = tc
        return out
    }
}
