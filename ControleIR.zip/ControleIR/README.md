# Controle IR (Poco F7 / HyperOS)

App Android sem anúncios, sem dependências externas e sem animações. Usa a API nativa
`ConsumerIrManager` (emissor IR do Poco F7, na borda superior do aparelho).

## Como gerar o APK

**Android Studio (mais fácil):** `File > Open` nesta pasta, aguarde o sync, depois
`Build > Build Bundle(s) / APK(s) > Build APK(s)`. Para a versão otimizada, escolha a variante
`release` em `Build > Select Build Variant`.

**Linha de comando:** `./gradlew assembleRelease` (precisa de JDK 17+ e Android SDK 35).
O APK sai em `app/build/outputs/apk/release/`.

## Como instalar no Poco F7

Copie o APK para o celular e abra, ou use `adb install app-release.apk`.
No HyperOS, instalar por USB exige ativar "Instalar via USB" nas Opções do desenvolvedor.

## Uso

- Chips no topo: Samsung, LG, Sony, RC5 (Philips antigas e outras) e **Pers.** (personalizado).
- O botão dispara no instante do toque. VOL, setas repetem se você segurar.
- Botão apagado = aquele perfil não tem o código.
- **Editar**: abre o perfil Pers. (começa como cópia do Samsung). Toque no banner amarelo para
  escolher protocolo (NEC, Samsung32, Sony 12 bits, RC5) e endereço; toque num botão para digitar o
  comando em hex. "Salvar e testar" já transmite o código.

## Observações

- Os códigos dos perfis vêm de bases públicas e foram escritos de memória, sem teste em TV real.
  Samsung e LG são os mais seguros; navegação Sony e perfil RC5 são os menos garantidos.
- TVs recentes da Philips usam RC6 (não implementado). Se a sua TV for outra marca, passe o modelo
  (ou os códigos de outro app) e eu ajusto os perfis.
- A animação de abrir/fechar apps é do sistema. Para eliminá-la, ajuste a escala de animação nas
  Opções do desenvolvedor.
