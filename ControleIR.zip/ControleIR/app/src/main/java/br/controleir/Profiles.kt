package br.controleir

enum class Key(val label: String, val repeat: Boolean = false) {
    POWER("POWER"), SOURCE("Fonte"), MUTE("Mudo"),
    VOL_UP("VOL +", true), VOL_DOWN("VOL −", true),
    CH_UP("CH +"), CH_DOWN("CH −"),
    UP("▲︎", true), DOWN("▼︎", true), LEFT("◀︎", true), RIGHT("▶︎", true),
    OK("OK"),
    BACK("Voltar"), HOME("Home"), MENU("Menu"), EXIT("Sair"),
    D0("0"), D1("1"), D2("2"), D3("3"), D4("4"), D5("5"), D6("6"), D7("7"), D8("8"), D9("9")
}

class Profile(val name: String, val proto: Proto, val addr: Int, val codes: Map<Key, Int>)

/**
 * Códigos de memória de bases públicas (lirc/IRDB). Botão ausente no mapa = fica apagado.
 * Teste no seu aparelho; use o perfil "Pers." para corrigir qualquer código.
 */
object Presets {
    private val DIGITS = listOf(Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6, Key.D7, Key.D8, Key.D9)
    private fun digits(f: (Int) -> Int): Map<Key, Int> = DIGITS.mapIndexed { n, k -> k to f(n) }.toMap()

    private val samsungDigits = intArrayOf(0x11, 0x04, 0x05, 0x06, 0x08, 0x09, 0x0A, 0x0C, 0x0D, 0x0E)

    val samsung = Profile(
        "Samsung", Proto.SAMSUNG, 0x07,
        mapOf(
            Key.POWER to 0x02, Key.SOURCE to 0x01, Key.MUTE to 0x0F,
            Key.VOL_UP to 0x07, Key.VOL_DOWN to 0x0B, Key.CH_UP to 0x48, Key.CH_DOWN to 0x4C,
            Key.UP to 0x60, Key.DOWN to 0x61, Key.LEFT to 0x65, Key.RIGHT to 0x62, Key.OK to 0x68,
            Key.BACK to 0x58, Key.HOME to 0x79, Key.MENU to 0x1A, Key.EXIT to 0x2D
        ) + digits { samsungDigits[it] }
    )

    val lg = Profile(
        "LG", Proto.NEC, 0x04,
        mapOf(
            Key.POWER to 0x08, Key.SOURCE to 0x0B, Key.MUTE to 0x09,
            Key.VOL_UP to 0x02, Key.VOL_DOWN to 0x03, Key.CH_UP to 0x00, Key.CH_DOWN to 0x01,
            Key.UP to 0x40, Key.DOWN to 0x41, Key.LEFT to 0x07, Key.RIGHT to 0x06, Key.OK to 0x44,
            Key.BACK to 0x28, Key.HOME to 0x7C, Key.MENU to 0x43, Key.EXIT to 0x5B
        ) + digits { 0x10 + it }
    )

    val sony = Profile(
        "Sony", Proto.SONY, 0x01,
        mapOf(
            Key.POWER to 0x15, Key.SOURCE to 0x25, Key.MUTE to 0x14,
            Key.VOL_UP to 0x12, Key.VOL_DOWN to 0x13, Key.CH_UP to 0x10, Key.CH_DOWN to 0x11,
            Key.UP to 0x74, Key.DOWN to 0x75, Key.LEFT to 0x34, Key.RIGHT to 0x33, Key.OK to 0x65,
            Key.BACK to 0x63, Key.MENU to 0x60
        ) + digits { if (it == 0) 0x09 else it - 1 }
    )

    val rc5 = Profile(
        "RC5", Proto.RC5, 0x00,
        mapOf(
            Key.POWER to 12, Key.SOURCE to 56, Key.MUTE to 13,
            Key.VOL_UP to 16, Key.VOL_DOWN to 17, Key.CH_UP to 32, Key.CH_DOWN to 33,
            Key.MENU to 82
        ) + digits { it }
    )

    val all: List<Profile> = listOf(samsung, lg, sony, rc5)
}
