package br.controleir

/** Protocolos suportados. periodMs = intervalo (início a início) entre repetições ao segurar o botão. */
enum class Proto(val label: String, val carrier: Int, val periodMs: Long) {
    NEC("NEC", 38000, 108),
    SAMSUNG("Samsung32", 38000, 108),
    SONY("Sony SIRC 12 bits", 40000, 135),
    RC5("RC5", 36000, 114)
}

/** Geradores de padrão (µs, começando por "ligado") para ConsumerIrManager.transmit. */
object Ir {

    private fun necLike(hdrMark: Int, hdrSpace: Int, bytes: IntArray): IntArray {
        val p = ArrayList<Int>(70)
        p.add(hdrMark)
        p.add(hdrSpace)
        for (b in bytes) {
            for (i in 0 until 8) {            // LSB primeiro
                p.add(560)
                p.add(if (((b shr i) and 1) == 1) 1690 else 560)
            }
        }
        p.add(560)                              // marca final
        return p.toIntArray()
    }

    /** NEC: endereço de 8 bits (+ inverso) ou, se > 0xFF, NEC estendido de 16 bits. */
    fun nec(addr: Int, cmd: Int): IntArray {
        val a = addr and 0xFFFF
        val c = cmd and 0xFF
        val bytes = if (a > 0xFF) {
            intArrayOf(a and 0xFF, (a shr 8) and 0xFF, c, c.inv() and 0xFF)
        } else {
            intArrayOf(a, a.inv() and 0xFF, c, c.inv() and 0xFF)
        }
        return necLike(9000, 4500, bytes)
    }

    /** Samsung32: endereço de 8 bits repetido duas vezes + comando + inverso. */
    fun samsung(addr: Int, cmd: Int): IntArray {
        val a = addr and 0xFF
        val c = cmd and 0xFF
        return necLike(4500, 4500, intArrayOf(a, a, c, c.inv() and 0xFF))
    }

    /** Sony SIRC: 7 bits de comando + (bits-7) bits de endereço, LSB primeiro, quadro a cada 45 ms. */
    fun sony(addr: Int, cmd: Int, bits: Int = 12, frames: Int = 3): IntArray {
        val addrBits = bits - 7
        val value = (cmd and 0x7F) or ((addr and ((1 shl addrBits) - 1)) shl 7)
        val p = ArrayList<Int>(100)
        for (f in 0 until frames) {
            var dur = 2400 + 600
            p.add(2400)
            p.add(600)
            for (i in 0 until bits) {
                val m = if (((value shr i) and 1) == 1) 1200 else 600
                p.add(m)
                p.add(600)
                dur += m + 600
            }
            if (f < frames - 1) {
                // troca o último espaço pelo intervalo que fecha 45 ms de início a início
                p[p.size - 1] = 45000 - (dur - 600)
            }
        }
        p.removeAt(p.size - 1)                  // termina na marca
        return p.toIntArray()
    }

    /** RC5 (Manchester, 36 kHz). cmd até 127 (bit 6 vai invertido no 2º bit de partida). */
    fun rc5(addr: Int, cmd: Int, toggle: Boolean): IntArray {
        val bits = ArrayList<Int>(14)
        bits.add(1)
        bits.add(if ((cmd and 0x40) != 0) 0 else 1)
        bits.add(if (toggle) 1 else 0)
        for (i in 4 downTo 0) bits.add((addr shr i) and 1)
        for (i in 5 downTo 0) bits.add((cmd shr i) and 1)

        // 1 = espaço+marca, 0 = marca+espaço
        val levels = ArrayList<Boolean>(28)
        for (b in bits) {
            if (b == 1) { levels.add(false); levels.add(true) } else { levels.add(true); levels.add(false) }
        }

        val p = ArrayList<Int>(30)
        var i = 0
        while (i < levels.size && !levels[i]) i++      // descarta o espaço inicial
        var cur = true
        var run = 0
        while (i < levels.size) {
            if (levels[i] == cur) {
                run += 889
            } else {
                p.add(run)
                cur = levels[i]
                run = 889
            }
            i++
        }
        if (cur) p.add(run)                             // se terminar em espaço, descarta
        return p.toIntArray()
    }
}
