package br.controleir

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast

private val C_BG = 0xFF0E1114.toInt()
private val C_KEY = 0xFF1E252B.toInt()
private val C_KEY_P = 0xFF3F4D58.toInt()
private val C_RED = 0xFFC62828.toInt()
private val C_RED_P = 0xFFFF5F52.toInt()
private val C_SEL = 0xFF2E7D5B.toInt()
private val C_EDIT = 0xFFB26A00.toInt()

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private var ir: ConsumerIrManager? = null

    // Thread dedicada ao IR: o toque nunca espera o transmit() terminar.
    private val irThread = HandlerThread("ir", Process.THREAD_PRIORITY_URGENT_DISPLAY)
    private lateinit var irHandler: Handler

    @Volatile private var current: Profile = Presets.all[0]
    @Volatile private var heldKey: Key? = null
    @Volatile private var heldToggle = false
    private var toggle = false

    private var selected = 0           // 0..3 = presets, 4 = personalizado
    private var editMode = false
    private var customProto = Proto.SAMSUNG
    private var customAddr = 0x07
    private val customCodes = HashMap<Key, Int>()

    private val keyViews = HashMap<Key, TextView>()
    private val chips = ArrayList<TextView>()
    private lateinit var editChip: TextView
    private lateinit var banner: TextView
    private var density = 1f

    private val repeater = object : Runnable {
        override fun run() {
            val k = heldKey ?: return
            val t0 = SystemClock.uptimeMillis()
            send(current, k, heldToggle)
            if (heldKey != null) irHandler.postAtTime(this, t0 + current.proto.periodMs)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        prefs = getSharedPreferences("ir", MODE_PRIVATE)
        irThread.start()
        irHandler = Handler(irThread.looper)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        loadCustom()
        selected = prefs.getInt("sel", 0).coerceIn(0, 4)
        setContentView(buildUi())
        refreshProfile()
        if (ir?.hasIrEmitter() != true) {
            Toast.makeText(this, "Este aparelho não reporta emissor infravermelho.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        release()
        super.onPause()
    }

    override fun onDestroy() {
        irThread.quitSafely()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- envio IR

    private fun press(k: Key) {
        if (!current.codes.containsKey(k)) return
        toggle = !toggle
        val tg = toggle
        irHandler.removeCallbacks(repeater)
        irHandler.post { send(current, k, tg) }
        if (k.repeat) {
            heldKey = k
            heldToggle = tg
            irHandler.postDelayed(repeater, 350)   // só repete se segurar
        } else {
            heldKey = null
        }
    }

    private fun release() {
        heldKey = null
        irHandler.removeCallbacks(repeater)
    }

    private fun send(p: Profile, k: Key, tg: Boolean) {
        val cmd = p.codes[k] ?: return
        val pattern = when (p.proto) {
            Proto.NEC -> Ir.nec(p.addr, cmd)
            Proto.SAMSUNG -> Ir.samsung(p.addr, cmd)
            Proto.SONY -> Ir.sony(p.addr, cmd)
            Proto.RC5 -> Ir.rc5(p.addr, cmd, tg)
        }
        try {
            ir?.transmit(p.proto.carrier, pattern)
        } catch (e: Exception) {
            // sem emissor ou sem permissão: ignora
        }
    }

    // ---------------------------------------------------------------- perfis

    private fun loadCustom() {
        if (prefs.getBoolean("c_init", false)) {
            val name = prefs.getString("c_proto", "")
            customProto = Proto.entries.firstOrNull { it.name == name } ?: Proto.SAMSUNG
            customAddr = prefs.getInt("c_addr", 0x07)
            for (k in Key.entries) {
                if (prefs.contains("c_" + k.name)) customCodes[k] = prefs.getInt("c_" + k.name, 0)
            }
        } else {
            val base = Presets.samsung            // ponto de partida do perfil personalizado
            customProto = base.proto
            customAddr = base.addr
            customCodes.putAll(base.codes)
        }
    }

    private fun saveCustom() {
        val e = prefs.edit()
        e.putBoolean("c_init", true)
        e.putString("c_proto", customProto.name)
        e.putInt("c_addr", customAddr)
        for (k in Key.entries) {
            val c = customCodes[k]
            if (c != null) e.putInt("c_" + k.name, c) else e.remove("c_" + k.name)
        }
        e.apply()
    }

    private fun refreshProfile() {
        current = if (selected == 4) Profile("Pers.", customProto, customAddr, HashMap(customCodes))
        else Presets.all[selected]
        for ((k, v) in keyViews) {
            v.alpha = if (editMode || current.codes.containsKey(k)) 1f else 0.28f
        }
        chips.forEachIndexed { i, c -> c.background = shape(if (i == selected) C_SEL else C_KEY, 10) }
        editChip.background = shape(if (editMode) C_EDIT else C_KEY, 10)
        banner.visibility = if (editMode) View.VISIBLE else View.GONE
        banner.text = "Edição: toque num botão para definir o código (hex) e testar.\n" +
            "${customProto.label} · endereço 0x${hex(customAddr)} — toque aqui para alterar"
    }

    private fun select(i: Int) {
        selected = i
        if (i != 4) editMode = false
        prefs.edit().putInt("sel", i).apply()
        refreshProfile()
    }

    private fun toggleEdit() {
        editMode = !editMode
        if (editMode && selected != 4) {
            selected = 4
            prefs.edit().putInt("sel", 4).apply()
        }
        release()
        refreshProfile()
    }

    // ---------------------------------------------------------------- diálogos de edição

    private fun protoDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val group = RadioGroup(this)
        Proto.entries.forEachIndexed { i, p ->
            val rb = RadioButton(this)
            rb.text = p.label
            rb.id = 1000 + i
            rb.isChecked = (p == customProto)
            group.addView(rb)
        }
        val addr = EditText(this)
        addr.hint = "Endereço (hex)"
        addr.setText(hex(customAddr))
        addr.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        box.addView(group)
        box.addView(addr)
        val b = AlertDialog.Builder(this)
            .setTitle("Protocolo e endereço")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val idx = group.checkedRadioButtonId - 1000
                if (idx in Proto.entries.indices) customProto = Proto.entries[idx]
                parseHex(addr.text.toString())?.let { customAddr = it }
                saveCustom()
                refreshProfile()
            }
            .setNegativeButton("Cancelar", null)
        showNoAnim(b)
    }

    private fun codeDialog(k: Key) {
        val et = EditText(this)
        et.hint = "Comando (hex)"
        et.setText(customCodes[k]?.let { hex(it) } ?: "")
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        et.setSelectAllOnFocus(true)
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        val b = AlertDialog.Builder(this)
            .setTitle("Botão ${k.label}")
            .setView(box)
            .setPositiveButton("Salvar e testar") { _, _ ->
                val c = parseHex(et.text.toString())
                if (c != null) {
                    customCodes[k] = c and 0xFF
                    saveCustom()
                    refreshProfile()
                    toggle = !toggle
                    val tg = toggle
                    irHandler.post { send(current, k, tg) }
                }
            }
            .setNeutralButton("Remover") { _, _ ->
                customCodes.remove(k)
                saveCustom()
                refreshProfile()
            }
            .setNegativeButton("Cancelar", null)
        showNoAnim(b)
    }

    private fun showNoAnim(b: AlertDialog.Builder) {
        val d = b.create()
        d.window?.setWindowAnimations(0)
        d.show()
    }

    // ---------------------------------------------------------------- interface

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C_BG)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(b.left + dp(6), b.top + dp(6), b.right + dp(6), b.bottom + dp(6))
            WindowInsets.CONSUMED
        }

        // perfis
        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        val names = listOf("Samsung", "LG", "Sony", "RC5", "Pers.")
        names.forEachIndexed { i, n ->
            val c = chip(n) { select(i) }
            chips.add(c)
            chipRow.addView(c, chipParams())
        }
        editChip = chip("Editar") { toggleEdit() }
        chipRow.addView(editChip, chipParams())
        root.addView(chipRow, LinearLayout.LayoutParams(MATCH, WRAP))

        banner = TextView(this)
        banner.textSize = 12f
        banner.setTextColor(0xFFFFC107.toInt())
        banner.setPadding(dp(8), dp(4), dp(8), dp(4))
        banner.visibility = View.GONE
        banner.setOnClickListener { protoDialog() }
        root.addView(banner, LinearLayout.LayoutParams(MATCH, WRAP))

        // linha de cima
        root.addView(
            hrow(1.1f, key(Key.POWER, C_RED, C_RED_P), key(Key.SOURCE), key(Key.MUTE))
        )

        // volume | direcional | canal
        val middle = LinearLayout(this)
        middle.orientation = LinearLayout.HORIZONTAL
        middle.layoutParams = LinearLayout.LayoutParams(MATCH, 0, 3.4f)

        val left = vcol(1.2f, key(Key.VOL_UP), key(Key.VOL_DOWN))
        val right = vcol(1.2f, key(Key.CH_UP), key(Key.CH_DOWN))
        val center = LinearLayout(this)
        center.orientation = LinearLayout.VERTICAL
        center.layoutParams = LinearLayout.LayoutParams(0, MATCH, 3f)
        center.addView(hrow(1f, View(this), key(Key.UP), View(this)))
        center.addView(hrow(1f, key(Key.LEFT), key(Key.OK), key(Key.RIGHT)))
        center.addView(hrow(1f, View(this), key(Key.DOWN), View(this)))
        middle.addView(left)
        middle.addView(center)
        middle.addView(right)
        root.addView(middle)

        // navegação
        root.addView(hrow(1f, key(Key.BACK), key(Key.HOME), key(Key.MENU), key(Key.EXIT)))

        // teclado numérico
        root.addView(hrow(1f, key(Key.D1, size = 20f), key(Key.D2, size = 20f), key(Key.D3, size = 20f)))
        root.addView(hrow(1f, key(Key.D4, size = 20f), key(Key.D5, size = 20f), key(Key.D6, size = 20f)))
        root.addView(hrow(1f, key(Key.D7, size = 20f), key(Key.D8, size = 20f), key(Key.D9, size = 20f)))
        root.addView(hrow(1f, View(this), key(Key.D0, size = 20f), View(this)))
        return root
    }

    private fun key(k: Key, color: Int = C_KEY, pressed: Int = C_KEY_P, size: Float = 17f): TextView {
        val t = TextView(this)
        t.text = k.label
        t.textSize = size
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.isSoundEffectsEnabled = false
        val bg = StateListDrawable()
        bg.addState(intArrayOf(android.R.attr.state_pressed), shape(pressed, 14))
        bg.addState(intArrayOf(), shape(color, 14))
        t.background = bg
        // Dispara no ACTION_DOWN (no instante do toque), sem esperar o "click" no soltar.
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    if (!editMode) {
                        press(k)
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    release()
                    if (editMode) codeDialog(k)
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    release()
                }
            }
            true
        }
        keyViews[k] = t
        return t
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.isSoundEffectsEnabled = false
        t.setOnClickListener { onClick() }
        return t
    }

    private fun chipParams(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        return lp
    }

    private fun hrow(weight: Float, vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(0, MATCH, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(v, lp)
        }
        r.layoutParams = LinearLayout.LayoutParams(MATCH, 0, weight)
        return r
    }

    private fun vcol(weight: Float, vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(MATCH, 0, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(v, lp)
        }
        r.layoutParams = LinearLayout.LayoutParams(0, MATCH, weight)
        return r
    }

    private fun shape(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    private fun hex(v: Int): String = Integer.toHexString(v).uppercase()

    private fun parseHex(s: String): Int? =
        s.trim().removePrefix("0x").removePrefix("0X").toIntOrNull(16)
}
